<?php
include_once 'connection.php';
session_start();
$newpass=$_POST['pass'];
$emailnew=$_SESSION['email'];
if(isset($_POST['fp'])){

  $clearq = "UPDATE user SET password = $newpass WHERE email = $emailnew;";
  if (mysqli_query($conn,$clearq)) {
}}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="fp2.css">
  <title>Forgot Password    </title>
</head>
<body>
  <div class="login-wrapper">
    <form action="fp2.php" method="POST" class="form">
      <img src="avatar.jpg" alt="">
      <h2>Reset Password</h2>
      <div class="input-group">
        <input type="password" name="pass" id="password" required>
        <label for="Enter new password">Password</label>
      </div>
      <input type="submit" value="Submit" class="submit-btn" name="fp2">

    </form>
