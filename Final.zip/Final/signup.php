<?php
include_once 'connection.php';
$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['password'];



if(empty($name) || empty($email) || empty($pass)){
  echo '<script>alert("One or more fields are empty.")</script>';
  echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
}

else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    echo '<script>alert("One or more fields are empty.")</script>';
    echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
} else {
  $sql="SELECT email FROM user where email=?";
  $stmt=mysqli_stmt_init($conn);
  if(!mysqli_stmt_prepare($stmt,$sql)){

    exit();
  }else{
    mysqli_stmt_bind_param($stmt, "s",$email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $resultCheck=mysqli_stmt_num_rows($stmt);
    if($resultCheck > 0){
      echo '<script>alert("User already exists.")</script>';
      echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
    }else{
      $sql="INSERT INTO user(name,email,password) VALUES ('$name','$email','$pass');";
    mysqli_query($conn,$sql);
    echo '<script>alert("Thank You For Registering With Us.")</script>';
  echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
    }
  }
}

?>
