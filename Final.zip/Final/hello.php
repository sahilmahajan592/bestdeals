<?php
require "iflogin.php" ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" type="text/css" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="profile.css">
    <meta charset="utf-8">
    <title></title>


  </head>
  <body>

    <div class="container">
        <div class="main">
            <div class="topbar">
                <a href="productsview.php">Home</a>
            </div>
            <div class="row">
                <div class="col-md-4 mt-1">
                    <div class="card text-center sidebar">
                        <div class="card-body">
                            <img src="images/icon.jpg" class="rounded-circle" width="150">
                            <div class="mt-3">
                                <h3><?php session_start();
                                echo $_SESSION['namep'];
                                ?></h3>
                                <a href="logout.php">Logout</a>
                                

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 mt-1">
                    <div class="card mb-3 content">
                        <h1 class="m-3 pt-3">About</h1>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <h5> Full Name</h5>
                                    <h5><?php

                                    echo $_SESSION['namep'];
                                    ?></h5>
                                </div>
                                <div class="col -md -9 text-secondary">
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Email</h5>
                                    <h5><?php echo $_SESSION['useree']; ?></h5>
                                </div>
                                <div class="=col-md-9 text-secondary">
                                     </div>
                            </div>

                            </div>
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </body>
    </html>
