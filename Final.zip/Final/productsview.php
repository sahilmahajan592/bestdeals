<?php
include_once 'connection.php';
session_start();
$query = "select * from product;";
$sub = mysqli_query($conn,$query);
$i=-1;
while($q = mysqli_fetch_array($sub)){
  $i++;
  $answer[$i]['brand']=$q['brand'];
  $answer[$i]['proname']=$q['proname'];
  $answer[$i]['descr']=$q['descr'];
  $answer[$i]['img']=$q['img'];
  $answer[$i]['cost']=$q['cost'];
  $answer[$i]['qty']=$q['qty'];
}

echo $_SESSION['idforus'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;700&display=swap" rel="stylesheet" />

  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />


  <!-- Carousel -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.theme.min.css
">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- Custom StyleSheet -->
  <link rel="stylesheet" href="styless.css" />

  <title>Phone Shop</title>
</head>

<body>
  <header id="header" class="header">
    <div class="navigation">
      <div class="container">
        <nav class="nav">
          <div class="nav__hamburger">

          </div>

          <div class="nav__logo">
            <a href="/" class="scroll-link">
              PHONE DEALS
            </a>
          </div>

          <div class="nav__menu">
            <div class="menu__top">
              <span class="nav__category">PHONE </span>
              <a href="#" class="close__toggle">

              </a>
            </div>
            <ul class="nav__list">
              <li class="nav__item" >
                <a href="#header" id ="homebtn" class="nav__link scroll-link">Home</a>
              </li>
              <li class="nav__item">
                <a href="cart2.php" id="cartbtn" class="nav__link scroll-link">Cart</a>
              </li>
              <li class="nav__item">
                <a href="hello.php" id="probtn" class="nav__link scroll-link">Profile</a>
              </li>
              <li class="nav__item">
                <a href="logout.php" id="probtn" class="nav__link scroll-link">Logout</a>
              </li>
            </ul>
          </div>









          </div>
        </nav>
      </div>
    </div>
    <div class="hero">
      <div class="glide" id="glide_1">
        <div class="glide__track" data-glide-el="track">
          <ul class="glide__slides">
            <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span class="">New Inspiration 2020</span>
                  <h1 class="">PHONES MADE FOR YOU!</h1>
                  <p>Trending from mobile and headphone style collection</p>
                  <a href="#"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <div class="hero__img-container">
                    <img class="banner_01" src="images/banner_01.png" alt="banner2" />
                  </div>
                </div>
              </div>
            </li>
            <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span>New Inspiration 2020</span>
                  <h1>PHONES MADE FOR YOU!</h1>
                  <p>Trending from mobile and headphone style collection</p>
                  <a href="#"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="images/banner_02.png" alt="banner2" />
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="glide__bullets" data-glide-el="controls[nav]">
          <button class="glide__bullet" data-glide-dir="=0"></button>
          <button class="glide__bullet" data-glide-dir="=1"></button>
        </div>

        <div class="glide__arrows" data-glide-el="controls">
          <button class="glide__arrow glide__arrow--left" data-glide-dir="<">

          </button>
          <button class="glide__arrow glide__arrow--right" data-glide-dir=">">

          </button>
        </div>
      </div>
    </div>
  </header>
  <!-- End Header -->
  <main id="main">
    <div class="container">
      <!-- Collection -->
      <!-- Latest Products -->
      <section class="section latest__products" id="latest">
        <div class="title__container">
          <div class="section__title active" data-id="Latest Products">
            <span class="dot"></span>
            <h1 class="primary__title">Latest Products</h1>
          </div>
        </div>
  <form action="cart2.php" method="POST">
        <li class="glide__slide">
          <div class="product">
            <div class="product__header">
              <img src="<?php echo $answer[0]['img']?>" alt="product">
            </div>
            <div class="product__footer">
              <h3 name="hello"><?php echo $answer[0]['proname']; ?> </h3>

              <div class="product__price">
                <h4><?php echo $answer[0]['cost']; ?></h4>
              </div>
            </div>

            <button type="submit" name="cart" class="product__btn">Add to Cart</button></form>
            </ul>
          </div>
            </li>
            <li class="glide__slide">
              <div class="product">
                <div class="product__header">
                  <img src="<?php echo $answer[1]['img']?>" alt="product">
                </div>
                <div class="product__footer">
                  <h3><?php echo $answer[1]['proname']; ?> </h3>

                  <div class="product__price">
                    <h4><?php echo $answer[1]['cost'] ?></h4>
                  </div>
                </div>
                <form action="cart2.php" method="POST">
                <button type="submit" name="cart1" class="product__btn">Add to Cart</button></form>
                </ul>
              </div>
                </li>
                <li class="glide__slide">
                  <div class="product">
                    <div class="product__header">
                      <img src="<?php echo $answer[2]['img']?>" alt="product">
                    </div>
                    <div class="product__footer">
                      <h3><?php echo $answer[2]['proname']; ?> </h3>

                      <div class="product__price">
                        <h4><?php echo $answer[2]['cost'] ?></h4>
                      </div>
                    </div>
                    <form action="cart2.php" method="POST">
                    <button type="submit" name="cart2" class="product__btn">Add to Cart</button></form>
                    </ul>
                  </div>
                    </li>
</body>
</html>
