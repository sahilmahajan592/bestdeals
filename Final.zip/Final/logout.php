<?php
include_once 'connection.php';
session_start();
echo '<script>alert("Logged Out Successfully.")</script>';
session_destroy();
echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
?>
