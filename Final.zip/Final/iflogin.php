<?php
include_once 'connection.php';
if(isset($_POST['login-submit'])){


$mail=$_POST['mailid'];
$password=$_POST['mailpass'];
$sql="SELECT * FROM user WHERE email=?;";
$stmt = mysqli_stmt_init($conn);
if(!mysqli_stmt_prepare($stmt,$sql)){
  header("Location: ../hello.php?error=sqlerror");
  exit();

}
else{
  mysqli_stmt_bind_param($stmt,"s",$mail);
  mysqli_stmt_execute($stmt);
  $result=mysqli_stmt_get_result($stmt);

  if($row = mysqli_fetch_assoc($result)){
    if($password!=$row['password']){
      echo '<script>alert("Password entered is wrong.")</script>';


//Send a Refresh header to the browser.
echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";

    }
    else if($password==$row['password']){
      session_start();
      $_SESSION['username']=$row['name'];
      $_SESSION['useree']=$row['email'];
      $_SESSION['idforus']=$row['id'];
      $_SESSION['namep']=$row['name'];
      header('Location: http://localhost/Final/productsview.php');
      //  echo "<script type='text/javascript'> document.location = 'hello.php'; </script>";
    }

  }else{
    echo '<script>alert("No user found.")</script>';


  //Send a Refresh header to the browser.
  echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";

  }
}
}




 ?>
