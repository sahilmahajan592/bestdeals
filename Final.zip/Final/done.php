<?php
include_once 'connection.php';

if(isset($_POST['checkedout'])){
session_start();
  $query = "DELETE FROM `cart` WHERE `cart`.`order_id`>1";
  if (mysqli_query($conn,$query)) {
}
else{
  echo "error";
}}
else{
  echo "<script type='text/javascript'> document.location = 'productsview.php'; </script>";
}
echo '<script>alert("Redirecting to User Profile after successfull purchase.")</script>';


//Send a Refresh header to the browser.
echo "<script type='text/javascript'> document.location = 'hello.php'; </script>";
 ?>
