<?php
include_once 'connection.php';
session_start();
$email=$_POST['email'];
$pass=$_POST['password'];
echo $pass;
if(isset($_POST['fp'])){
$sql="SELECT email FROM user where email=?";
$stmt=mysqli_stmt_init($conn);
if(!mysqli_stmt_prepare($stmt,$sql)){
echo '<script>alert("SQL ERROR.")</script>';
  exit();
}else{
  mysqli_stmt_bind_param($stmt, "s",$email);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_store_result($stmt);
  $resultCheck=mysqli_stmt_num_rows($stmt);
  if($resultCheck > 0){

    $clearq = "UPDATE user SET password = '$pass' WHERE email = '$email';";
    if (mysqli_query($conn,$clearq)) {
      echo '<script>alert("Password changed successfully.")</script>';
      echo "<script type='text/javascript'> document.location = 'Login.php'; </script>";
  }
  }
else{
  echo '<script>alert("No user with email found.")</script>';
  echo "<script type='text/javascript'> document.location = 'fp.php'; </script>";
}}}
  else{
    echo "eh";
  }
?>
