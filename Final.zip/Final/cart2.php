<?php error_reporting(0); ?>
<?php

include_once 'connection.php';
if(isset($_POST['cle'])){
  session_start();
  $clearq = "DELETE FROM `cart` WHERE `cart`.`order_id`>1;";
  if (mysqli_query($conn,$clearq)) {
}}
if(isset($_POST['cart'])){

session_start();
$usforid= $_SESSION['idforus'];
$query = "select * from product;";
$sub = mysqli_query($conn,$query);
$i=-1;
while($q = mysqli_fetch_array($sub)){
  $i++;
  $answer[$i]['proname']=$q['proname'];
  $answer[$i]['cost']=$q['cost'];
  $answer[$i]['qty']=$q['qty'];
  $showname=$answer[0]['proname'];
  $showcost=$answer[0]['cost'];
  $showqty=$answer[0]['qty'];}
 $query1 = "INSERT INTO cart VALUES ('','$usforid','$showname','$showcost','$showqty'); ";
//  $sub1 = mysqli_query($conn,$query1);
if (mysqli_query($conn,$query1)) {

}

}else if(isset($_POST['cart1'])){
  session_start();
  $usforid= $_SESSION['idforus'];
  $query = "select * from product;";
  $sub = mysqli_query($conn,$query);
  $i=-1;
  while($q = mysqli_fetch_array($sub)){
    $i++;
    $answer[$i]['proname']=$q['proname'];
    $answer[$i]['cost']=$q['cost'];
    $answer[$i]['qty']=$q['qty'];
    $showname=$answer[1]['proname'];
    $showcost=$answer[1]['cost'];
    $showqty=$answer[1]['qty'];}
   $query2 = "INSERT INTO cart VALUES ('','$usforid','$showname','$showcost','$showqty');";
  //  $sub1 = mysqli_query($conn,$query1);
  if (mysqli_query($conn,$query2)) {

  }

}
else if(isset($_POST['cart2'])){
  session_start();
  $usforid= $_SESSION['idforus'];
  $query = "select * from product;";
  $sub = mysqli_query($conn,$query);
  $i=-1;
  while($q = mysqli_fetch_array($sub)){
    $i++;
    $answer[$i]['proname']=$q['proname'];
    $answer[$i]['cost']=$q['cost'];
    $answer[$i]['qty']=$q['qty'];
    $showname=$answer[2]['proname'];
    $showcost=$answer[2]['cost'];
    $showqty=$answer[2]['qty'];}
   $query3 = "INSERT INTO cart VALUES ('','$usforid','$showname','$showcost','$showqty');";
  //  $sub1 = mysqli_query($conn,$query1);
  if (mysqli_query($conn,$query3)) {

  }

}
 ?>
 <?php

 $sql1 = "select * from cart;";
 $sub = mysqli_query($conn,$sql1);
 $i=-1;
 while($q = mysqli_fetch_array($sub)){
   $i++;
  $fet[$i]['namepro']=$q['namepro'];
  $fet[$i]['costpro']=$q['costpro'];
  $fet[$i]['qty']=$q['qty'];
 }

 ?>
 <!doctype html>
 <html lang="en">
   <head>
     <title> Cart</title>
     <!-- Required meta tags -->
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <link rel="stylesheet"href="main.css">
     <link rel="stylesheet"href="cart2.css">
     <script src="https://kit.fontawesome.com/332a215f17.js" crossorigin="anonymous"></script>

     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   </head>
   <body>
     <section>
         <div class="cover">
             <div class="container">
                 <div class="row">
                     <div class="col-md-6 d-flex justify-content-md-end">
                         <div class="social-icon mr-4">
                             <p class="mb-0 d-flex">
                                 <a href="#" class="d-flex align-items-center
                                 justify-content-center">
                             <i class="fab fa-facebook"></i></a>
                             <a href="#" class="d-flex align-items-center
                                 justify-content-center">
                             <i class="fab fa-instagram"></i></a>
                             <a href="#" class="d-flex align-items-center
                                 justify-content-center">
                             <i class="fab fa-twitter"></i></a>
                             </p>
                         </div>
                     </div>
                 </div>

             </div>
         </div>
         <!--Nav-->
         <nav class="navbar navbar-expand-lg main-navbar bg-color main-navbar-color"
         id="main-navbar">
         <div class="container">

             <button class="navbar-toggler" type="button" data-toggle="collapse"
             data-target="#myNav" aria-controls="nav" aria-expanded="false"
             aria-label="Toggle navigation">
         <i class="fas fa-bars"></i></button>
         <div class="collapse navbar-collapse"id="myNav">
             <ul class="navbar-nav ml-auto">
                 <li class="nav-item">
                     <a href="productsview.php"class="nav-link">Continue Shopping</a>
                 </li>
                   </ul>
         </div>
         </div>
         </nav>
         <!--End of Nav-->
     </section>
     <!--Cart Section-->
     <section class="mt-5">
         <div class="container">
             <div class="cart">
             <div class="table-responsive">
                 <table class="table">
                     <thead class="thead-dark">
                         <tr>
                             <th scope="col"class="text-white">Product</th>
                             <th scope="col"class="text-white">Price</th>
                             <th scope="col"class="text-white">Quantity</th>
                             <th scope="col"class="text-white">Total</th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>
                                 <div class="main">
                                     <div class="d-flex">
                       <img src="images/"alt="">
                                     </div>
                                     <div class="des">
                                         <p><?php

                                         if($fet[1]['namepro']!=null){
                                           echo $fet[1]['namepro'];
                                           $fl=1;

                                         }else if($fet[2]['namepro']!=null){
                                           echo $fet[2]['namepro'];
                                           $fl=2;

                                         }else if($fet[3]['namepro']!=null){
                                           echo $fet[3]['namepro'];
                                           $fl=3;
                                         }
                                         ?></p>
                                     </div>
                                 </div>
                             </td>
                             <td>
                               <p><?php if($fet[1]['costpro']!=null){
                                 echo $fet[1]['costpro'];
                                 $cl=1;

                               }else if($fet[2]['costpro']!=null){
                                 echo $fet[2]['costpro'];
                                 $cl=2;

                               }else if($fet[3]['costpro']!=null){
                                 echo $fet[3]['costpro'];
                                 $cl=3;
                               } ?></p>
                             </td>
                             <td>

                             </td>
                             <td>

                             </td>
                         </tr>
                         <!----->
                         <tr>
                             <td>
                                 <div class="main">
                                     <div class="d-flex">
                      <!--W=145 H=98--> <img src="images/"alt="">
                                     </div>
                                     <div class="des">
                                       <p><?php

                                         if(($fet[2]['namepro']!=null)&&($fl!=2))
                                        {
                                          echo $fet[2]['namepro'];
                                          $fl=2;

                                        }else if(($fet[3]['namepro']!=null)&&($fl!=3)){
                                          echo $fet[3]['namepro'];
                                          $fl=3;
                                        }?>
                                       </p>
                                     </div>
                                 </div>
                             </td>
                             <td>
                               <?php

                                 if(($fet[2]['costpro']!=null)&&($cl!=2))
                                {
                                  echo $fet[2]['costpro'];
                                  $cl=2;

                                }else if(($fet[3]['costpro']!=null)&&($cl!=3)){
                                  echo $fet[3]['costpro'];
                                  $cl=3;
                                }?>
                             </td>
                             <td>

                             </td>
                             <td>

                             </td>
                         </tr>
                         <!----->
                         <tr>
                             <td>
                                 <div class="main">
                                     <div class="d-flex">
                      <!--W=145 H=98--> <img src="images/"alt="">
                                     </div>
                                     <div class="des">
                                       <p><?php

                                         if(($fet[2]['namepro']!=null)&&($fl!=2))
                                        {
                                          echo $fet[2]['namepro'];
                                          $fl=2;

                                        }else if(($fet[3]['namepro']!=null)&&($fl!=3)){
                                          echo $fet[3]['namepro'];
                                          $fl=3;
                                        }?></p>
                                     </div>
                                 </div>
                             </td>
                             <td>
                               <?php

                                 if(($fet[2]['costpro']!=null)&&($cl!=2))
                                {
                                  echo $fet[2]['costpro'];
                                  $cl=2;

                                }else if(($fet[3]['costpro']!=null)&&($cl!=3)){
                                  echo $fet[3]['costpro'];
                                  $cl=3;
                                }?>
                             </td>
                             <td>
                                
                             </td>
                             <td>

                             </td>
                         </tr>
                         <!----->
                     </tbody>
                 </table>
             </div>
             </div>
         </div>
     </section>
     <div class="col-lg-4 offset-lg-4">
         <div class="checkout">
             <ul>
                 <li class="subtotal">subtotal
                  <?php $result = mysqli_query($conn, 'SELECT SUM(costpro) AS value_sum FROM cart');
$row = mysqli_fetch_assoc($result);
$sum = $row['value_sum'];
echo "     ".$sum;?>
                 </li>
                 <li class="cart-total">Total<?php echo "     ".$sum;?>
                 </li>
             </ul>
             <form action="payment.php" method="POST">
               <button type="submit" name="pay" class= "proceed-btn">Proceed to Checkout</button>
             </form>
             <form action="cart2.php" method="POST">
               <button type="submit" name="cle" class= "proceed-btn">Clear Cart & Return</button>
             </form>
         </div>
     </div>


















     <!-- Optional JavaScript -->
     <!-- jQuery first, then Popper.js, then Bootstrap JS -->
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   </body>
 </html>
