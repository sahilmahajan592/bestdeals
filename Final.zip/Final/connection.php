<?php

$dbServername="localhost";
$dbUsername="root";
$dbPass="";
$dbName="bestdeal";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPass,$dbName);

 ?>
